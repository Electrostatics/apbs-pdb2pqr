var group___vcap =
[
    [ "vcap.h", "vcap_8h.html", null ],
    [ "vcap.c", "vcap_8c.html", null ],
    [ "EXPMAX", "group___vcap.html#ga23d246eba89dbfca722195812576a8a4", null ],
    [ "EXPMIN", "group___vcap.html#gacb93f1a1f5c89b3aa0d99937f0e6a1ef", null ],
    [ "Vcap_cosh", "group___vcap.html#ga31c184963273be04fe5663afab0b62c2", null ],
    [ "Vcap_exp", "group___vcap.html#ga3af96d10891f3150377104c65689c6ec", null ],
    [ "Vcap_sinh", "group___vcap.html#gaf2a951f624d6b8c0e5d1b7708fd0cc74", null ]
];