var NAVTREE =
[
  [ "APBS", "index.html", [
    [ "APBS Programmers Guide", "index.html", null ],
    [ "Related Pages", "pages.html", [
      [ "Todo List", "todo.html", null ],
      [ "Deprecated List", "deprecated.html", null ],
      [ "Bug List", "bug.html", null ]
    ] ],
    [ "Modules", "modules.html", [
      [ "Vcsm class", "group___vcsm.html", null ],
      [ "Vfetk class", "group___vfetk.html", null ],
      [ "Vpee class", "group___vpee.html", null ],
      [ "APOLparm class", "group___a_p_o_lparm.html", null ],
      [ "FEMparm class", "group___f_e_mparm.html", null ],
      [ "MGparm class", "group___m_gparm.html", null ],
      [ "NOsh class", "group___n_osh.html", null ],
      [ "PBEparm class", "group___p_b_eparm.html", null ],
      [ "Vacc class", "group___vacc.html", null ],
      [ "Valist class", "group___valist.html", null ],
      [ "Vatom class", "group___vatom.html", null ],
      [ "Vcap class", "group___vcap.html", null ],
      [ "Vclist class", "group___vclist.html", null ],
      [ "Vgreen class", "group___vgreen.html", null ],
      [ "Vhal class", "group___vhal.html", null ],
      [ "Vparam class", "group___vparam.html", null ],
      [ "Vpbe class", "group___vpbe.html", null ],
      [ "Vstring class", "group___vstring.html", null ],
      [ "Vunit class", "group___vunit.html", null ],
      [ "Vgrid class", "group___vgrid.html", null ],
      [ "Vmgrid class", "group___vmgrid.html", null ],
      [ "Vopot class", "group___vopot.html", null ],
      [ "Vpmg class", "group___vpmg.html", null ],
      [ "Vpmgp class", "group___vpmgp.html", null ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "sAPOLparm", "structs_a_p_o_lparm.html", null ],
      [ "sFEMparm", "structs_f_e_mparm.html", null ],
      [ "sMGparm", "structs_m_gparm.html", null ],
      [ "sNOsh", "structs_n_osh.html", null ],
      [ "sNOsh_calc", "structs_n_osh__calc.html", null ],
      [ "sPBEparm", "structs_p_b_eparm.html", null ],
      [ "sVacc", "structs_vacc.html", null ],
      [ "sVaccSurf", "structs_vacc_surf.html", null ],
      [ "sValist", "structs_valist.html", null ],
      [ "sVatom", "structs_vatom.html", null ],
      [ "sVclist", "structs_vclist.html", null ],
      [ "sVclistCell", "structs_vclist_cell.html", null ],
      [ "sVcsm", "structs_vcsm.html", null ],
      [ "sVfetk", "structs_vfetk.html", null ],
      [ "sVfetk_LocalVar", "structs_vfetk___local_var.html", null ],
      [ "sVgreen", "structs_vgreen.html", null ],
      [ "sVgrid", "structs_vgrid.html", null ],
      [ "sVmgrid", "structs_vmgrid.html", null ],
      [ "sVopot", "structs_vopot.html", null ],
      [ "sVparam_AtomData", "structs_vparam___atom_data.html", null ],
      [ "sVpbe", "structs_vpbe.html", null ],
      [ "sVpee", "structs_vpee.html", null ],
      [ "sVpmg", "structs_vpmg.html", null ],
      [ "sVpmgp", "structs_vpmgp.html", null ],
      [ "Vparam", "struct_vparam.html", null ],
      [ "Vparam_ResData", "struct_vparam___res_data.html", null ]
    ] ],
    [ "Data Structure Index", "classes.html", null ],
    [ "Data Fields", "functions.html", null ],
    [ "File List", "files.html", [
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/doc/license/LICENSE.h", "_l_i_c_e_n_s_e_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/doc/programmer/mainpage.h", null, null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/aaa_inc/apbs/apbs.h", "apbs_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/aaa_lib/apbs_link.c", "apbs__link_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/fem/dummy.c", "dummy_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/fem/vcsm.c", "vcsm_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/fem/vfetk.c", "vfetk_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/fem/vpee.c", "vpee_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/fem/apbs/vcsm.h", "vcsm_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/fem/apbs/vfetk.h", "vfetk_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/fem/apbs/vpee.h", "vpee_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apolparm.c", "apolparm_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/femparm.c", "femparm_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/mgparm.c", "mgparm_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/nosh.c", "nosh_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/pbeparm.c", "pbeparm_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/vacc.c", "vacc_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/valist.c", "valist_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/vatom.c", "vatom_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/vcap.c", "vcap_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/vclist.c", "vclist_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/vgreen.c", "vgreen_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/vparam.c", "vparam_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/vpbe.c", "vpbe_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/vstring.c", "vstring_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/apolparm.h", null, null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/femparm.h", "femparm_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/mgparm.h", "mgparm_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/nosh.h", "nosh_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/pbeparm.h", "pbeparm_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vacc.h", "vacc_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/valist.h", "valist_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vatom.h", "vatom_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vcap.h", "vcap_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vclist.h", "vclist_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vgreen.h", "vgreen_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vhal.h", "vhal_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vparam.h", "vparam_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vpbe.h", "vpbe_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vstring.h", "vstring_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/generic/apbs/vunit.h", "vunit_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/vgrid.c", "vgrid_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/vmgrid.c", "vmgrid_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/vopot.c", "vopot_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/vpmg.c", "vpmg_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/vpmgp.c", "vpmgp_8c.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/apbs/vgrid.h", "vgrid_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/apbs/vmgrid.h", "vmgrid_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/apbs/vopot.h", "vopot_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/apbs/vpmg.h", "vpmg_8h.html", null ],
      [ "C:/Users/bake113/Documents/Projects/APBS & PDB2PQR/Source code/APBS/src/mg/apbs/vpmgp.h", "vpmgp_8h.html", null ]
    ] ],
    [ "Globals", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

