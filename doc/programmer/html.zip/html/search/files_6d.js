var searchData=
[
  ['mgparm_2ec',['mgparm.c',['../mgparm_8c.html',1,'']]],
  ['mgparm_2eh',['mgparm.h',['../mgparm_8h.html',1,'']]]
];
