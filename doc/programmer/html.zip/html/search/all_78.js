var searchData=
[
  ['x_5fsize',['x_size',['../structs_vmultigrid.html#aa84601b56e801ce086fd86309a13e695',1,'sVmultigrid']]],
  ['xcent',['xcent',['../structs_vpmgp.html#a1fd8a9e50b513a92ce2ac6bb86fe671f',1,'sVpmgp']]],
  ['xf',['xf',['../structs_vpmg.html#a9cda7e2ef5f9819681ad21169e634b50',1,'sVpmg']]],
  ['xkappa',['xkappa',['../structs_vpbe.html#a6357524b27017c8f57f3078a338b44df',1,'sVpbe']]],
  ['xlen',['xlen',['../structs_vpmgp.html#a9ef23ea2587b7b978becada47514941e',1,'sVpmgp']]],
  ['xmax',['xmax',['../structs_vgrid.html#a30554afc6599846bcd01cbf986d0998a',1,'sVgrid::xmax()'],['../structs_vpmgp.html#a30554afc6599846bcd01cbf986d0998a',1,'sVpmgp::xmax()']]],
  ['xmin',['xmin',['../structs_vgrid.html#ab5bbe897a0c25c58341c216a1b31fbbf',1,'sVgrid::xmin()'],['../structs_vpmgp.html#ab5bbe897a0c25c58341c216a1b31fbbf',1,'sVpmgp::xmin()']]],
  ['xp',['xp',['../structs_vgreen.html#a7df365c58843453a02cae2d62640973b',1,'sVgreen']]],
  ['xpts',['xpts',['../structs_vacc_surf.html#adc11c159667b978601b182a72c2f3776',1,'sVaccSurf']]],
  ['xq',['xq',['../structs_vfetk___local_var.html#a6cf209441633d47579a3c90faa8b220e',1,'sVfetk_LocalVar']]]
];
