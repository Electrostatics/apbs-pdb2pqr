var group___vpmgp =
[
    [ "vpmgp.h", "vpmgp_8h.html", null ],
    [ "vpmgp.c", "vpmgp_8c.html", null ],
    [ "sVpmgp", "structs_vpmgp.html", null ],
    [ "Vpmgp", "group___vpmgp.html#ga2912920cad25d13afbe194bd6447c5ab", null ],
    [ "Vpmgp_ctor", "group___vpmgp.html#gacbf93b72154285b4a1789400f6cb5aa2", null ],
    [ "Vpmgp_ctor2", "group___vpmgp.html#ga11a970ff00cb1de38da826b8f1ae6e2a", null ],
    [ "Vpmgp_dtor", "group___vpmgp.html#ga34b2134038fac6b41b02e67492105c07", null ],
    [ "Vpmgp_dtor2", "group___vpmgp.html#ga0362aaae83d2078bdb2e555a4b2fc00c", null ],
    [ "Vpmgp_makeCoarse", "group___vpmgp.html#ga0b65b886427a0d09e8ace8d117e7e0ea", null ],
    [ "Vpmgp_size", "group___vpmgp.html#gadb713e70f5724ce0f63ec4cf380278d7", null ]
];