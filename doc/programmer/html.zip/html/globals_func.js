var globals_func =
[
    [ "a", "globals_func.html", null ],
    [ "b", "globals_func_0x62.html", null ],
    [ "d", "globals_func_0x64.html", null ],
    [ "f", "globals_func_0x66.html", null ],
    [ "g", "globals_func_0x67.html", null ],
    [ "i", "globals_func_0x69.html", null ],
    [ "m", "globals_func_0x6d.html", null ],
    [ "n", "globals_func_0x6e.html", null ],
    [ "p", "globals_func_0x70.html", null ],
    [ "q", "globals_func_0x71.html", null ],
    [ "r", "globals_func_0x72.html", null ],
    [ "s", "globals_func_0x73.html", null ],
    [ "v", "globals_func_0x76.html", null ],
    [ "z", "globals_func_0x7a.html", null ]
];